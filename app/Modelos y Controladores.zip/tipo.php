<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tipo extends Model
{
     protected $primaryKey='_id';
protected $collection= 'tipo';
}
