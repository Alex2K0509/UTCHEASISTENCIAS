<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Grupos extends Model
{
    protected $primaryKey='Id_grupo';
protected $collection= 'UTCHEASIST2';
}
