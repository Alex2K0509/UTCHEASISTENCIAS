<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carreras extends Model
{
    protected $primaryKey='Id_Asignatura';
protected $collection= 'UTCHEASIST2';
}
