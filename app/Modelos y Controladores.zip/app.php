<?php

return [
....
'Providers'=>[

Jenssegers\Mongodb\MongodbServiceProvider::class,

]
.....

]